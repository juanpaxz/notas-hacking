## Description

Can you get the flag?

Additional details will be available after launching your challenge instance.
### Solucion

```
picoCTF{gr4d3_A_c00k13_5d2505be}
```
### Notas Adicionales
cookie = isadmin = 1     response
### Referencias
https://youtu.be/IKhn6kHzSsU