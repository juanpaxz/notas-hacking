## Description

Can you get the flag?

Additional details will be available after launching your challenge instance.
### Solucion

```
picoCTF{1n5p3t0r_0f_h7ml_8113f7e2}
```
### Notas Adicionales
ver origen de la pagina
### Referencias
https://youtu.be/2DHRoKV8ahQ