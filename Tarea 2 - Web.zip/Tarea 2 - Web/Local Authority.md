## Description

Can you get the flag?

Additional details will be available after launching your challenge instance.
### Solucion

```
picoCTF{j5_15_7r4n5p4r3n7_05df90c8}
```
### Notas Adicionales
ver contraseña en el js picoCTF{j5_15_7r4n5p4r3n7_05df90c8}
### Referencias
https://youtu.be/PgYT8FX4Jm8