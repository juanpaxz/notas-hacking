## Description

I don't like scrolling down to read the code of my website, so I've squished it. As a bonus, my pages load faster!

Additional details will be available after launching your challenge instance.
### Solucion

```
picoCTF{pr3tty_c0d3_dbe259ce}
```
### Notas Adicionales
buscar entre los divs del inspector
### Referencias
https://youtu.be/gqWbHrm3ECY