## Description

Can you login to this website?

Additional details will be available after launching your challenge instance.
### Solucion

```
picoCTF{L00k5_l1k3_y0u_solv3d_it_d3c660ac}
```
### Notas Adicionales
'admin' or 1=1--
### Referencias
https://youtu.be/FNVx9hCSwTY