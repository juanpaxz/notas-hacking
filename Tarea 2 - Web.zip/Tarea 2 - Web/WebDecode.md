## Description

Do you know how to use the web inspector?

Additional details will be available after launching your challenge instance.
### Solucion

```
picoCTF{web_succ3ssfully_d3c0ded_f6f6b78a}
```
### Notas Adicionales
inspecsionar la pagina y decode base 64
### Referencias
https://youtu.be/dNPRanpV8Tc