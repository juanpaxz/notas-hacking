## Description

Can you get the flag?

Additional details will be available after launching your challenge instance.
### Solucion

```
picoCTF{1nclu51v17y_1of2_f7w_2of2_df589022}
```
### Notas Adicionales
 ver origen de la pagina y ver script.js 
### Referencias
https://youtu.be/YObk5GKM3zA