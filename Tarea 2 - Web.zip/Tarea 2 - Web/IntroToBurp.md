## Description

Additional details will be available after launching your challenge instance.
### Solucion

```
picoCTF{#0TP_Bypvss_SuCc3$S_3e3ddc76}
```
### Notas Adicionales
usar burpsite para interceptar foward hasta llegar a la autenticacion
### Referencias
https://youtu.be/TQbPfP48Dhk